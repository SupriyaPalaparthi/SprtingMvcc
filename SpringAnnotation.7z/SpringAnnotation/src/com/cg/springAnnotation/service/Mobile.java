package com.cg.springAnnotation.service;

import org.springframework.stereotype.Component;

@Component("mob")
public class Mobile {
	
	
int mobileId;
	String mobileName;
	double mobilePrice;
	
	public int getMobileId() {
		return mobileId;
	}

public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

public String getMobileName() {
		return mobileName;
	}

public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

public double getMobilePrice() {
		return mobilePrice;
	}

public void setMobilePrice(double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}

public void printMobileDetails(){
   //System.out.println("Id is"+mobileId+ "Name is"+mobileName+ "Price is"+mobilePrice);
   System.out.println("In Mobile Data...");
	}
}
