package com.cg.springdemotwo.service;

import java.util.List;


public class Mobile {
	
	int mobileId;
	String mobileName;
	double mobilePrice;
	List<Inventory> invent;
	
	public List<Inventory> getInvent() {
		return invent;
	}

	public void setInvent(List<Inventory> invent) {
		this.invent = invent;
	}

	public int getMobileId() {
		return mobileId;
	}

public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

public String getMobileName() {
		return mobileName;
	}

public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

public double getMobilePrice() {
		return mobilePrice;
	}

public void setMobilePrice(double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}


/*public Mobile(int mobileId, String mobileName, double mobilePrice){
		
		this.mobileId=mobileId;
		this.mobileName=mobileName;
		this.mobilePrice=mobilePrice;
		
	}*/
	public void printMobileDetails(){
		System.out.println("Id is"+mobileId+ "Name is"+mobileName+ "Price is"+mobilePrice);
		//System.out.println("Mobile count is"+invent.mobileCount+ "Mobile company is"+invent.mobileCompany);
	
	for(Inventory in : invent)
	{
		System.out.println("Mobile count is"+in.mobileCount+ "Mobile company is"+in.mobileCompany);
	}
	}

}
