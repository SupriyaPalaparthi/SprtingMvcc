package com.cg.springdemotwo.service;

public class Inventory {
	int mobileCount;
	String mobileCompany;
	
	public int getMobileCount() {
		return mobileCount;
	}
	public void setMobileCount(int mobileCount) {
		this.mobileCount = mobileCount;
	}
	public String getMobileCompany() {
		return mobileCompany;
	}
	public void setMobileCompany(String mobileCompany) {
		this.mobileCompany = mobileCompany;
	}
	
}
