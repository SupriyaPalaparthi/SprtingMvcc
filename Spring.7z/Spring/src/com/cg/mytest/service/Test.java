package com.cg.mytest.service;

public class Test {

	public static void main(String[] args)
	{
		Shape shape = ShapeInfo.showShape("Cir");
		shape.getShape();
	}

}
